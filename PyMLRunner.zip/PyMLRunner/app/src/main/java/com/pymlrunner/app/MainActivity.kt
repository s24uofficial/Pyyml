package com.pymlrunner.app

import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import com.chaquo.python.Python
import com.chaquo.python.PyObject
import com.chaquo.python.android.AndroidPlatform
import com.pymlrunner.app.databinding.ActivityMainBinding
import com.pymlrunner.app.databinding.ItemInputBinding
import com.pymlrunner.app.databinding.LayoutOutputBinding
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

// ---------------------------------------------------------------------------
// Template definitions (the Python code itself lives in ml_runner.py)
// ---------------------------------------------------------------------------

data class InputSpec(
    val key: String,      // must match the variable name used in ml_runner.py
    val label: String,
    val default: String,
    val hint: String
)

data class MlTemplate(
    val id: String,       // must match the key in TEMPLATES in ml_runner.py
    val emoji: String,
    val title: String,
    val description: String,
    val inputs: List<InputSpec>
)

private val TEMPLATES = listOf(
    MlTemplate(
        id = "house",
        emoji = "🏠",
        title = "House Price Prediction",
        description = "Linear Regression trained on 60 sample houses. Change the numbers and the model predicts the price in ₹ Lakh.",
        inputs = listOf(
            InputSpec("area", "Area (sq ft)", "1200", "Try 500 to 3000"),
            InputSpec("bedrooms", "Bedrooms", "3", "Try 1 to 5"),
            InputSpec("age", "House age (years)", "5", "Try 0 to 30")
        )
    ),
    MlTemplate(
        id = "study",
        emoji = "📚",
        title = "Study Hours vs Marks",
        description = "Linear Regression on hours studied per day vs marks out of 100.",
        inputs = listOf(
            InputSpec("study_hours", "Study hours per day", "6", "Try 1 to 10 (decimals allowed)")
        )
    ),
    MlTemplate(
        id = "iris",
        emoji = "🌸",
        title = "Iris Classifier",
        description = "K-Nearest-Neighbours trained on the classic Iris dataset. Enter flower measurements in cm.",
        inputs = listOf(
            InputSpec("sepal_length", "Sepal length (cm)", "5.1", "Typical range 4.3 to 7.9"),
            InputSpec("sepal_width", "Sepal width (cm)", "3.5", "Typical range 2.0 to 4.4"),
            InputSpec("petal_length", "Petal length (cm)", "1.4", "Typical range 1.0 to 6.9"),
            InputSpec("petal_width", "Petal width (cm)", "0.2", "Typical range 0.1 to 2.5")
        )
    )
)

private val CUSTOM_SAMPLE = """
# Custom Mode: np (numpy) and plt (matplotlib) are already imported.
# print() goes to the output box. Set  result = "..."  for a big headline.
from sklearn.linear_model import LinearRegression

X = np.array([[1], [2], [3], [4], [5], [6]])
y = np.array([2.1, 4.3, 6.2, 8.1, 10.4, 12.2])

model = LinearRegression().fit(X, y)
x_new = 7
pred = model.predict([[x_new]])[0]

print("Slope:", round(float(model.coef_[0]), 3))
print("Intercept:", round(float(model.intercept_), 3))
result = f"Prediction for x = {x_new}  →  {pred:.2f}"

plt.figure(figsize=(6, 4))
plt.scatter(X, y, label="data")
plt.plot(X, model.predict(X), "r-", label="fit")
plt.scatter([x_new], [pred], marker="*", s=250, c="gold", edgecolors="black", label="prediction")
plt.legend()
plt.title("My first custom model")
""".trimIndent()

// ---------------------------------------------------------------------------
// Activity
// ---------------------------------------------------------------------------

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // One background thread for ALL Python calls: keeps the UI smooth and Python access sequential.
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val plotDir: String by lazy { File(cacheDir, "plots").absolutePath }

    private var currentTemplate: MlTemplate? = null
    private val inputRows = mutableListOf<Pair<InputSpec, ItemInputBinding>>()
    private var lastTemplateCode: String? = null
    private var codePanelOpen = false
    private val refreshCodeRunnable = Runnable { refreshCodePreview() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupInsets()
        setupHome()
        setupTemplateScreen()
        setupCustomScreen()
        setupBackNavigation()

        binding.etCode.setText(CUSTOM_SAMPLE)
        warmUpPython()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.root.removeCallbacks(refreshCodeRunnable)
        worker.shutdown()
    }

    // ----------------------------- setup -----------------------------

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
    }

    private fun setupHome() {
        binding.cardHouse.setOnClickListener { openTemplate(TEMPLATES[0]) }
        binding.cardStudy.setOnClickListener { openTemplate(TEMPLATES[1]) }
        binding.cardIris.setOnClickListener { openTemplate(TEMPLATES[2]) }
        binding.cardCustom.setOnClickListener { showScreen(binding.screenCustom) }
    }

    private fun setupTemplateScreen() {
        binding.btnBackTemplate.setOnClickListener { showScreen(binding.screenHome) }
        binding.btnRunTemplate.setOnClickListener { runTemplate() }
        binding.btnToggleCode.setOnClickListener { toggleCodePanel() }
        binding.btnEditInCustom.setOnClickListener {
            val code = lastTemplateCode
            if (code == null) {
                toast("Code is still loading, try again in a moment")
            } else {
                binding.etCode.setText(code)
                binding.outCustom.root.visibility = View.GONE
                showScreen(binding.screenCustom)
            }
        }
    }

    private fun setupCustomScreen() {
        binding.btnBackCustom.setOnClickListener { showScreen(binding.screenHome) }
        binding.btnResetCustom.setOnClickListener { binding.etCode.setText(CUSTOM_SAMPLE) }
        binding.btnRunCustom.setOnClickListener {
            val code = binding.etCode.text?.toString().orEmpty()
            if (code.isBlank()) {
                toast("Write some Python code first")
            } else {
                runPython(
                    out = binding.outCustom,
                    runButton = binding.btnRunCustom,
                    scroll = binding.screenCustom,
                    buildCode = { code }
                )
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.screenHome.visibility == View.VISIBLE) {
                    finish()
                } else {
                    showScreen(binding.screenHome)
                }
            }
        })
    }

    // ----------------------------- navigation -----------------------------

    private fun showScreen(screen: ScrollView) {
        listOf(binding.screenHome, binding.screenTemplate, binding.screenCustom).forEach {
            it.visibility = if (it === screen) View.VISIBLE else View.GONE
        }
        screen.scrollTo(0, 0)
        hideKeyboard()
    }

    private fun openTemplate(template: MlTemplate) {
        currentTemplate = template
        lastTemplateCode = null
        codePanelOpen = false

        binding.tvTemplateTitle.text = "${template.emoji} ${template.title}"
        binding.tvTemplateDesc.text = template.description

        // Build the input boxes
        binding.inputsContainer.removeAllViews()
        inputRows.clear()
        template.inputs.forEach { spec ->
            val row = ItemInputBinding.inflate(layoutInflater, binding.inputsContainer, false)
            row.tilInput.hint = spec.label
            row.tilInput.helperText = spec.hint
            row.etValue.setText(spec.default)
            row.etValue.doAfterTextChanged {
                row.tilInput.error = null
                if (codePanelOpen) scheduleCodeRefresh()
            }
            binding.inputsContainer.addView(row.root)
            inputRows.add(spec to row)
        }

        // Reset code + output panels
        binding.cardCode.visibility = View.GONE
        binding.btnToggleCode.text = "👁 View Python Code"
        binding.outTemplate.root.tag = null          // ignore any result still in flight
        binding.outTemplate.root.visibility = View.GONE
        binding.btnRunTemplate.isEnabled = true

        showScreen(binding.screenTemplate)
    }

    // ----------------------------- inputs & code preview -----------------------------

    /** Reads all input boxes. Returns null (and optionally flags the boxes) if any value is invalid. */
    private fun readInputs(showErrors: Boolean): JSONObject? {
        val json = JSONObject()
        var allValid = true
        for ((spec, row) in inputRows) {
            val value = row.etValue.text?.toString()?.trim()?.replace(',', '.')?.toDoubleOrNull()
            if (value == null || !value.isFinite()) {
                allValid = false
                if (showErrors) row.tilInput.error = "Enter a valid number"
            } else {
                row.tilInput.error = null
                json.put(spec.key, value)
            }
        }
        return if (allValid) json else null
    }

    private fun toggleCodePanel() {
        codePanelOpen = !codePanelOpen
        binding.cardCode.visibility = if (codePanelOpen) View.VISIBLE else View.GONE
        binding.btnToggleCode.text =
            if (codePanelOpen) "🙈 Hide Python Code" else "👁 View Python Code"
        if (codePanelOpen) refreshCodePreview()
    }

    private fun scheduleCodeRefresh() {
        binding.root.removeCallbacks(refreshCodeRunnable)
        binding.root.postDelayed(refreshCodeRunnable, 400)
    }

    private fun refreshCodePreview() {
        val template = currentTemplate ?: return
        val values = readInputs(showErrors = false)
        if (values == null) {
            binding.tvCode.text = "# Enter valid numbers in all boxes to see the code"
            return
        }
        binding.tvCode.text = "# Loading code…"
        val valuesJson = values.toString()
        worker.execute {
            val result = runCatching {
                python().getModule("ml_runner")
                    .callAttr("build_code", template.id, valuesJson).toString()
            }
            onUi {
                result
                    .onSuccess { code ->
                        lastTemplateCode = code
                        binding.tvCode.text = code
                    }
                    .onFailure { binding.tvCode.text = "# Could not build code:\n# ${it.message}" }
            }
        }
    }

    // ----------------------------- running Python -----------------------------

    private fun runTemplate() {
        val template = currentTemplate ?: return
        val values = readInputs(showErrors = true)
        if (values == null) {
            toast("Please fix the highlighted boxes")
            return
        }
        val valuesJson = values.toString()
        runPython(
            out = binding.outTemplate,
            runButton = binding.btnRunTemplate,
            scroll = binding.screenTemplate,
            buildCode = { module ->
                module.callAttr("build_code", template.id, valuesJson).toString()
            },
            onCodeReady = { code ->
                lastTemplateCode = code
                binding.tvCode.text = code
            }
        )
    }

    /**
     * Runs `buildCode` + ml_runner.run_code on the worker thread and shows the result in [out].
     * Results that arrive after the user left the screen are ignored.
     */
    private fun runPython(
        out: LayoutOutputBinding,
        runButton: View,
        scroll: ScrollView,
        buildCode: (PyObject) -> String,
        onCodeReady: (String) -> Unit = {}
    ) {
        hideKeyboard()
        val token = System.nanoTime()
        out.root.tag = token
        runButton.isEnabled = false
        out.root.visibility = View.VISIBLE
        out.progress.visibility = View.VISIBLE
        out.cardResult.visibility = View.GONE

        worker.execute {
            val json = try {
                val module = python().getModule("ml_runner")
                val code = buildCode(module)
                onUi { onCodeReady(code) }
                module.callAttr("run_code", code, plotDir).toString()
            } catch (t: Throwable) {
                errorJson(t)
            }
            onUi {
                runButton.isEnabled = true
                if (out.root.tag == token) showResult(json, out, scroll)
            }
        }
    }

    private fun showResult(json: String, out: LayoutOutputBinding, scroll: ScrollView) {
        out.progress.visibility = View.GONE
        out.cardResult.visibility = View.VISIBLE

        val obj = try {
            JSONObject(json)
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", json)
        }
        val ok = obj.optBoolean("ok", false)
        val headline = obj.optString("headline", "")
        val output = obj.optString("output", "")
        val error = obj.optString("error", "")
        val elapsed = obj.optDouble("elapsed", 0.0)
        val imagePath = obj.optString("image", "")

        // Headline
        if (ok) {
            out.tvHeadline.setTextColor(Color.parseColor("#2E7D32"))
            out.tvHeadline.text = headline.ifBlank { "✅ Code ran successfully" }
        } else {
            out.tvHeadline.setTextColor(Color.parseColor("#B3261E"))
            out.tvHeadline.text = "⚠️ Something went wrong"
        }

        // Graph
        val bitmap = if (imagePath.isNotBlank() && File(imagePath).exists()) {
            BitmapFactory.decodeFile(imagePath)
        } else null
        if (bitmap != null) {
            out.ivPlot.setImageBitmap(bitmap)
            out.ivPlot.visibility = View.VISIBLE
        } else {
            out.ivPlot.setImageDrawable(null)
            out.ivPlot.visibility = View.GONE
        }

        // Details text
        val details = StringBuilder()
        if (!ok && error.isNotBlank()) details.append(error)
        if (output.isNotBlank()) {
            if (details.isNotEmpty()) details.append("\n\nOutput before the error:\n")
            details.append(output)
        }
        if (ok && elapsed > 0.0) {
            if (details.isNotEmpty()) details.append("\n\n")
            details.append(String.format(Locale.US, "⏱ Ran in %.2f s", elapsed))
        }
        out.tvDetails.text = details.toString()
        out.tvDetails.visibility = if (details.isEmpty()) View.GONE else View.VISIBLE

        out.root.post { scroll.smoothScrollTo(0, out.root.top) }
    }

    // ----------------------------- Python helpers -----------------------------

    /** Starts Python on first use. Always call from the worker thread. */
    private fun python(): Python {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(applicationContext))
        }
        return Python.getInstance()
    }

    /** Starts Python in the background at launch and shows the installed package versions. */
    private fun warmUpPython() {
        worker.execute {
            val result = runCatching {
                python().getModule("ml_runner").callAttr("get_versions").toString()
            }
            onUi {
                binding.tvEngine.text = result.fold(
                    onSuccess = { "✅ $it" },
                    onFailure = { "⚠️ Python engine problem: ${it.message}" }
                )
            }
        }
    }

    private fun errorJson(t: Throwable): String =
        JSONObject()
            .put("ok", false)
            .put("error", t.message ?: t.toString())
            .toString()

    // ----------------------------- small utilities -----------------------------

    private fun onUi(block: () -> Unit) {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) block()
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        val focused = currentFocus ?: return
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(focused.windowToken, 0)
    }
}
