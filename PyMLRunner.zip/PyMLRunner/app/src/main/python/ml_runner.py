"""PyML Runner - Python engine (runs inside Chaquopy on the phone, fully offline).

Kotlin calls three functions:
  get_versions()                      -> short text with installed package versions
  build_code(template_id, values_json) -> full Python source of a template with your inputs filled in
  run_code(code, out_dir)             -> JSON string {ok, headline, output, image, error, elapsed}

The code shown in the app is EXACTLY the code that gets executed, for templates and Custom Mode alike.
"""
import contextlib
import glob
import io
import json
import math
import os
import sys
import time
import traceback

# ---------------------------------------------------------------------------
# Template bodies (plain Python / scikit-learn). Input variables such as
# `area` or `study_hours` are injected above the body by build_code().
# ---------------------------------------------------------------------------

HOUSE_BODY = r'''
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

# --- Training data: 60 synthetic houses (price in Rs Lakh) ---
rng = np.random.default_rng(42)
areas = rng.uniform(500, 3000, 60)          # sq ft
beds = rng.integers(1, 6, 60)               # 1 to 5 bedrooms
ages = rng.uniform(0, 30, 60)               # years
prices = 5 + 0.045 * areas + 6 * beds - 0.35 * ages + rng.normal(0, 3, 60)

# --- Train a Linear Regression model ---
X = np.column_stack([areas, beds, ages])
model = LinearRegression().fit(X, prices)
fitted = model.predict(X)
r2 = r2_score(prices, fitted)

# --- Predict for YOUR house ---
predicted = float(model.predict([[area, bedrooms, age]])[0])

result = f"Estimated price: ₹ {predicted:,.2f} Lakh"
print(f"Model R2 score : {r2:.3f}")
print(f"Coef (area)    : {model.coef_[0]:.4f} Lakh per sq ft")
print(f"Coef (bedrooms): {model.coef_[1]:.3f} Lakh per bedroom")
print(f"Coef (age)     : {model.coef_[2]:.3f} Lakh per year")
print(f"Intercept      : {model.intercept_:.2f}")

# --- Graph: actual vs model price ---
plt.figure(figsize=(6, 4.2))
plt.scatter(prices, fitted, alpha=0.6, label="Training houses")
lims = [min(prices.min(), fitted.min()), max(prices.max(), fitted.max())]
plt.plot(lims, lims, "r--", label="Perfect fit")
plt.scatter([predicted], [predicted], marker="*", s=300, c="gold",
            edgecolors="black", zorder=5, label="Your house")
plt.xlabel("Actual price (Rs Lakh)")
plt.ylabel("Model price (Rs Lakh)")
plt.title("House price - Linear Regression")
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
'''

STUDY_BODY = r'''
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

# --- Training data: hours studied per day -> marks out of 100 ---
hours = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)
marks = np.array([35, 41, 47, 52, 60, 63, 71, 78, 84, 90])

# --- Train a Linear Regression model ---
model = LinearRegression().fit(hours, marks)
r2 = r2_score(marks, model.predict(hours))

# --- Predict marks for YOUR study hours (kept between 0 and 100) ---
predicted = float(np.clip(model.predict([[study_hours]])[0], 0, 100))

result = f"{study_hours:g} hours/day → about {predicted:.1f} marks"
print(f"Slope     : {model.coef_[0]:.2f} marks per extra hour")
print(f"Intercept : {model.intercept_:.2f}")
print(f"R2 score  : {r2:.3f}")

# --- Graph: data points, regression line and your prediction ---
line_x = np.linspace(0, 12, 50).reshape(-1, 1)
plt.figure(figsize=(6, 4.2))
plt.scatter(hours, marks, label="Students (training data)")
plt.plot(line_x, np.clip(model.predict(line_x), 0, 100), "r-", label="Regression line")
plt.scatter([study_hours], [predicted], marker="*", s=300, c="gold",
            edgecolors="black", zorder=5, label="Your prediction")
plt.xlabel("Study hours per day")
plt.ylabel("Marks")
plt.ylim(0, 105)
plt.title("Study Hours vs Marks")
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
'''

IRIS_BODY = r'''
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# --- Load the classic Iris dataset (150 flowers, 3 species) ---
iris = load_iris()
X, y = iris.data, iris.target
names = iris.target_names

# --- Train a K-Nearest-Neighbours classifier ---
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y)
model = KNeighborsClassifier(n_neighbors=5).fit(X_train, y_train)
accuracy = model.score(X_test, y_test)

# --- Classify YOUR flower ---
sample = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
pred = int(model.predict(sample)[0])
proba = model.predict_proba(sample)[0]

result = f"Predicted species: {str(names[pred]).title()}"
print(f"Test accuracy: {accuracy:.1%}")
print("Confidence:")
for name, p in zip(names, proba):
    print(f"  {str(name):<12} {p:.0%}")

# --- Graph: petal length vs petal width ---
plt.figure(figsize=(6, 4.2))
for i, name in enumerate(names):
    plt.scatter(X[y == i, 2], X[y == i, 3], alpha=0.7, label=str(name))
plt.scatter([petal_length], [petal_width], marker="*", s=350, c="black",
            zorder=5, label="Your flower")
plt.xlabel("Petal length (cm)")
plt.ylabel("Petal width (cm)")
plt.title("Iris Classifier (KNN)")
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
'''

TEMPLATES = {
    "house": {
        "title": "House Price Prediction (Linear Regression)",
        "inputs": ["area", "bedrooms", "age"],
        "body": HOUSE_BODY,
    },
    "study": {
        "title": "Study Hours vs Marks Predictor (Linear Regression)",
        "inputs": ["study_hours"],
        "body": STUDY_BODY,
    },
    "iris": {
        "title": "Iris Flower Classifier (K-Nearest Neighbours)",
        "inputs": ["sepal_length", "sepal_width", "petal_length", "petal_width"],
        "body": IRIS_BODY,
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fmt(value):
    """Format a number for the generated code (1200.0 -> 1200, 5.1 -> 5.1)."""
    v = float(value)
    if not math.isfinite(v):
        raise ValueError("Input values must be finite numbers")
    if v.is_integer() and abs(v) < 1e15:
        return repr(int(v))
    return repr(v)


def _short_error(exc):
    """One readable error message that points at the line in the user's code."""
    msg = "".join(traceback.format_exception_only(type(exc), exc)).strip()
    line = None
    if isinstance(exc, SyntaxError) and exc.lineno:
        line = exc.lineno
    else:
        for frame in traceback.extract_tb(exc.__traceback__):
            if frame.filename == "<ml_code>":
                line = frame.lineno
    if line:
        msg += "\n(at line %d of your code)" % line
    return msg


def _save_figure(plt, out_dir):
    """Save the most recent Matplotlib figure as PNG and return its path ('' if none)."""
    if not plt.get_fignums():
        return ""
    os.makedirs(out_dir, exist_ok=True)
    for old in glob.glob(os.path.join(out_dir, "plot_*.png")):
        try:
            os.remove(old)
        except OSError:
            pass
    fig = plt.figure(plt.get_fignums()[-1])
    path = os.path.join(out_dir, "plot_%d.png" % int(time.time() * 1000))
    fig.savefig(path, dpi=110, bbox_inches="tight", facecolor="white")
    return path


# ---------------------------------------------------------------------------
# Public API (called from Kotlin)
# ---------------------------------------------------------------------------

def get_versions():
    import numpy
    import scipy
    import sklearn
    import matplotlib
    return "Python %s · numpy %s · scikit-learn %s · matplotlib %s" % (
        sys.version.split()[0], numpy.__version__, sklearn.__version__, matplotlib.__version__)


def build_code(template_id, values_json):
    """Return the full source of a template with the user's input values filled in."""
    tpl = TEMPLATES[template_id]
    values = json.loads(values_json)
    lines = [
        "# " + tpl["title"],
        "# Change the numbers in the app (or edit them here in Custom Mode) and run again.",
        "",
        "# --- Your inputs ---",
    ]
    for key in tpl["inputs"]:
        lines.append("%s = %s" % (key, _fmt(values[key])))
    lines.append("")
    lines.append(tpl["body"].strip())
    return "\n".join(lines) + "\n"


def run_code(code, out_dir):
    """Run Python code, capture print() output, the optional `result` variable and the last plot."""
    out = {"ok": True, "headline": "", "output": "", "image": "", "error": "", "elapsed": 0.0}
    started = time.time()
    buf = io.StringIO()
    plt = None
    try:
        os.makedirs(out_dir, exist_ok=True)
        os.environ.setdefault("MPLCONFIGDIR", os.path.join(out_dir, "mplconfig"))
        os.makedirs(os.environ["MPLCONFIGDIR"], exist_ok=True)
        os.environ["MPLBACKEND"] = "Agg"

        import numpy as np
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.show = lambda *args, **kwargs: None   # no window on Android; we save the figure instead
        plt.close("all")

        namespace = {"__name__": "__main__", "np": np, "plt": plt}
        try:
            with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                exec(compile(code, "<ml_code>", "exec"), namespace)
        except (Exception, SystemExit) as exc:
            out["ok"] = False
            out["error"] = _short_error(exc)

        if out["ok"]:
            if namespace.get("result") is not None:
                out["headline"] = str(namespace["result"])
            out["image"] = _save_figure(plt, out_dir)
    except Exception as exc:  # e.g. a package failed to import
        out["ok"] = False
        out["error"] = _short_error(exc)
    finally:
        if plt is not None:
            try:
                plt.close("all")
            except Exception:
                pass

    out["output"] = buf.getvalue().strip()[-20000:]
    out["elapsed"] = round(time.time() - started, 2)
    return json.dumps(out)
